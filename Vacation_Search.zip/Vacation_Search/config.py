weather_api_key = "cc73567ca04a213a67034d5e8202e89c"
g_key = "AIzaSyC3R4XzigjA3jey8M_AimbEvFF-aDia4EU"